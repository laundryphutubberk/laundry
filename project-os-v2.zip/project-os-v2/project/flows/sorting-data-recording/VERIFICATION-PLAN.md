# Sorting and Data Recording Verification Plan

Status: DRAFT

## Required Evidence

- generic transitions cannot bypass type/color/data validation;
- Type confirmation rejects missing/inactive Item Type;
- Color confirmation rejects empty color;
- classification correction cannot change counted quantity or Bag linkage;
- recording derives dimensions and quantities from persisted Count Lines only;
- concurrent/repeated recording cannot duplicate Movements;
- Movement set, Inventory Summary, Work status, and audit log commit atomically;
- rollback leaves no partial Movements/Summary/status;
- Resort reads remain scoped and Resort mutation is denied;
- browser confirmation, correction, recording, and refresh persist;
- completed Intake/Counting, Issue, and Image regressions pass.
